@echo off
setlocal DisableDelayedExpansion
set "BDE_DEST=%SystemRoot%\System32\IndependentBitLockerManager"
if not exist "%BDE_DEST%" mkdir "%BDE_DEST%"
if not exist "%BDE_DEST%" goto failed
copy /b /y "%~dp0bdemgr.exe" "%BDE_DEST%\BitLockerManager.exe" >nul
if errorlevel 1 goto failed
"%BDE_DEST%\BitLockerManager.exe" --install-doubleclick
exit /b %errorlevel%
:failed
echo Cannot install to "%BDE_DEST%". Run this script as administrator.
pause
exit /b 1
