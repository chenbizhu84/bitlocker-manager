@echo off
setlocal DisableDelayedExpansion
if "%~1"=="" goto usage
if /I not "%~nx1"=="bdemgr.exe" goto usage
if not exist "%~dp1bdemgr.anhdv-original.exe" goto usage
copy /b /y "%~dp1bdemgr.anhdv-original.exe" "%~f1" >nul
if errorlevel 1 goto failed
echo Original Anhdv program restored.
pause
exit /b 0
:usage
echo Drag the REPLACED bdemgr.exe onto this script. Its backup must be in the same folder.
pause
exit /b 1
:failed
echo Restore failed. Check permissions and close the running program.
pause
exit /b 1
