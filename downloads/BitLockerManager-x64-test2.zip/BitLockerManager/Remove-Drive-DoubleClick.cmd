@echo off
setlocal DisableDelayedExpansion
set "BDE_APP=%SystemRoot%\System32\IndependentBitLockerManager\BitLockerManager.exe"
if exist "%BDE_APP%" goto installed
"%~dp0bdemgr.exe" --remove-doubleclick
exit /b %errorlevel%
:installed
"%BDE_APP%" --remove-doubleclick
exit /b %errorlevel%
