@echo off
setlocal DisableDelayedExpansion
if "%~1"=="" goto usage
if /I not "%~nx1"=="bdemgr.exe" goto usage
if not exist "%~f1" goto usage
if /I "%~f1"=="%~dp0bdemgr.exe" goto usage
if not exist "%~dp0bdemgr.exe" goto failed
if exist "%~dp1bdemgr.anhdv-original.exe" goto backedup
copy /b "%~f1" "%~dp1bdemgr.anhdv-original.exe" >nul
if errorlevel 1 goto failed
:backedup
copy /b /y "%~dp0bdemgr.exe" "%~f1" >nul
if errorlevel 1 goto failed
echo Replacement complete. Original backup: "%~dp1bdemgr.anhdv-original.exe"
echo Test the existing Anhdv shortcut. If it restores the original EXE, update the source archive instead.
pause
exit /b 0
:usage
echo Drag the ORIGINAL Anhdv bdemgr.exe onto this script.
echo Do not drag the new EXE from this package.
pause
exit /b 1
:failed
echo Replacement failed. Check permissions and close the running program.
pause
exit /b 1
