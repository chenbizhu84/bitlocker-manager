#define _WIN32_WINNT 0x0601
#define WINVER 0x0601
#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define COBJMACROS
#include <windows.h>
#include <wbemidl.h>
#include <oleauto.h>
#include <stdio.h>
#include <wchar.h>
#include <stdlib.h>
#include <shellapi.h>
#include <shlobj.h>
#define DONE (WM_APP+1)
static HWND win, drives, secret, logbox, scanbtn, unlockbtn, radios[4], showbtn;
static int operation=0;
static WCHAR openLetter=0;
static BOOL openRequest=FALSE;
static BOOL launchedFromDrive=FALSE, unlockSucceeded=FALSE;
static int percentages[26], protections[26], conversions[26];
static WCHAR savedLetters[26],savedPaths[26][1024];
static int savedCount;
static WCHAR paths[26][1024], chosenpath[1024];
static BOOL busy;
static int action;
static WCHAR target[4], credential[1024];
static WCHAR report[32768];
static WCHAR letters[26]; static int locks[26], count;
static void append(const WCHAR *s){if(wcslen(report)+wcslen(s)<32760)wcscat(report,s);}
static HRESULT connect_wmi(IWbemLocator **loc,IWbemServices **svc){
 HRESULT h=CoCreateInstance(&CLSID_WbemLocator,NULL,CLSCTX_INPROC_SERVER,&IID_IWbemLocator,(void**)loc);
 if(FAILED(h))return h;
 BSTR ns=SysAllocString(L"ROOT\\CIMV2\\Security\\MicrosoftVolumeEncryption");
 h=IWbemLocator_ConnectServer(*loc,ns,NULL,NULL,NULL,0,NULL,NULL,svc);SysFreeString(ns);
 if(SUCCEEDED(h))h=CoSetProxyBlanket((IUnknown*)*svc,RPC_C_AUTHN_WINNT,RPC_C_AUTHZ_NONE,NULL,RPC_C_AUTHN_LEVEL_CALL,RPC_C_IMP_LEVEL_IMPERSONATE,NULL,EOAC_NONE);
 return h;
}
static void scan(void){
 savedCount=count;for(int i=0;i<count;i++){savedLetters[i]=letters[i];wcscpy(savedPaths[i],paths[i]);}

 IWbemLocator *loc=NULL;IWbemServices *svc=NULL;IEnumWbemClassObject *en=NULL;HRESULT h=connect_wmi(&loc,&svc); count=0;
 if(FAILED(h)){WCHAR s[256];swprintf(s,256,L"BitLocker WMI unavailable (0x%08lX).\r\nPE needs WinPE-WMI and WinPE-SecureStartup components.\r\n",(unsigned long)h);append(s);goto end;}
 BSTR lang=SysAllocString(L"WQL"),q=SysAllocString(L"SELECT DriveLetter, __PATH FROM Win32_EncryptableVolume");
 h=IWbemServices_ExecQuery(svc,lang,q,WBEM_FLAG_FORWARD_ONLY|WBEM_FLAG_RETURN_IMMEDIATELY,NULL,&en);SysFreeString(lang);SysFreeString(q);
 if(FAILED(h)){append(L"Cannot enumerate BitLocker volumes. Check PE components and administrator rights.\r\n");goto end;}
 for(;;){IWbemClassObject *obj=NULL,*out=NULL;ULONG got=0;h=IEnumWbemClassObject_Next(en,5000,1,&obj,&got);if(!got){if(h!=WBEM_S_FALSE)append(L"Scan incomplete or timed out. Try Refresh.\r\n");break;}
 VARIANT d,p,v;VariantInit(&d);VariantInit(&p);VariantInit(&v);
 IWbemClassObject_Get(obj,L"DriveLetter",0,&d,NULL,NULL);IWbemClassObject_Get(obj,L"__PATH",0,&p,NULL,NULL);
 if(d.vt==VT_BSTR&&d.bstrVal&&wcslen(d.bstrVal)>=2&&p.vt==VT_BSTR){
 int percent=-1, conversion=-1;IWbemClassObject *conv=NULL;BSTR cm=SysAllocString(L"GetConversionStatus");
 HRESULT ch=IWbemServices_ExecMethod(svc,p.bstrVal,cm,0,NULL,NULL,&conv,NULL);SysFreeString(cm);
 if(SUCCEEDED(ch)&&conv){VARIANT cv,pc,rc;VariantInit(&cv);VariantInit(&pc);VariantInit(&rc);IWbemClassObject_Get(conv,L"ReturnValue",0,&rc,NULL,NULL);
 if((rc.vt==VT_I4||rc.vt==VT_UI4)&&rc.ulVal==0){IWbemClassObject_Get(conv,L"ConversionStatus",0,&cv,NULL,NULL);IWbemClassObject_Get(conv,L"EncryptionPercentage",0,&pc,NULL,NULL);if(cv.vt==VT_I4||cv.vt==VT_UI4)conversion=(int)cv.lVal;if(pc.vt==VT_I4||pc.vt==VT_UI4)percent=(int)pc.lVal;}
 VariantClear(&cv);VariantClear(&pc);VariantClear(&rc);IWbemClassObject_Release(conv);}
 // Keep fully decrypted and protection-off volumes visible; never hide on conversion status.

 BSTR m=SysAllocString(L"GetLockStatus");h=IWbemServices_ExecMethod(svc,p.bstrVal,m,0,NULL,NULL,&out,NULL);SysFreeString(m);
 int locked=-1;if(SUCCEEDED(h)&&out){VARIANT ret;VariantInit(&ret);IWbemClassObject_Get(out,L"ReturnValue",0,&ret,NULL,NULL);if((ret.vt==VT_I4&&ret.lVal==0)||(ret.vt==VT_UI4&&ret.ulVal==0)){IWbemClassObject_Get(out,L"LockStatus",0,&v,NULL,NULL);if(v.vt==VT_I4||v.vt==VT_UI4)locked=(int)v.lVal;}VariantClear(&ret);}
 int protection=-1;IWbemClassObject *po=NULL;BSTR pm=SysAllocString(L"GetProtectionStatus");HRESULT ph=IWbemServices_ExecMethod(svc,p.bstrVal,pm,0,NULL,NULL,&po,NULL);SysFreeString(pm);
 if(SUCCEEDED(ph)&&po){VARIANT pv,pr;VariantInit(&pv);VariantInit(&pr);IWbemClassObject_Get(po,L"ReturnValue",0,&pr,NULL,NULL);if((pr.vt==VT_I4||pr.vt==VT_UI4)&&pr.ulVal==0){IWbemClassObject_Get(po,L"ProtectionStatus",0,&pv,NULL,NULL);if(pv.vt==VT_I4||pv.vt==VT_UI4)protection=(int)pv.lVal;}VariantClear(&pv);VariantClear(&pr);IWbemClassObject_Release(po);}
 if(count<26){percentages[count]=percent;protections[count]=protection;conversions[count]=conversion;letters[count]=d.bstrVal[0];locks[count]=locked;wcsncpy(paths[count],p.bstrVal,1023);paths[count][1023]=0;count++;}
 WCHAR line[160];swprintf(line,160,L"%ls   %ls\r\n",d.bstrVal,locked==1?L"LOCKED":locked==0?L"UNLOCKED":L"UNKNOWN");append(line);swprintf(line,160,L"     Protection: %ls\r\n",protection==1?L"ON":protection==0?L"OFF (suspended or not enabled)":L"UNKNOWN");append(line);if(percent>=0){swprintf(line,160,L"     Encrypted: %d%%; conversion state: %d\r\n",percent,conversion);append(line);}
 }else append(L"Volume without a drive letter: assign a letter in Disk Management or DiskPart to manage it here.\r\n");
 VariantClear(&d);VariantClear(&p);VariantClear(&v);if(out)IWbemClassObject_Release(out);IWbemClassObject_Release(obj);
 }
 // Preserve previously detected drives when a provider temporarily omits them.
 DWORD logical=GetLogicalDrives();
 for(int i=0;i<savedCount&&count<26;i++){WCHAR letter=savedLetters[i];BOOL found=FALSE;for(int j=0;j<count;j++)if(letters[j]==letter)found=TRUE;
 if(!found&&letter>=L'A'&&letter<=L'Z'&&(logical&(1UL<<(letter-L'A')))){letters[count]=letter;locks[count]=-1;protections[count]=-1;conversions[count]=-1;percentages[count]=-1;wcscpy(paths[count],savedPaths[i]);count++;WCHAR line[256];swprintf(line,256,L"%lc: STATUS UNAVAILABLE - retained from previous scan. Only Resume may be attempted; other operations require a fresh status.\r\n",letter);append(line);}}
 if(count==0)append(L"No manageable BitLocker volume with a drive letter found.\r\n");
end: if(en)IEnumWbemClassObject_Release(en);if(svc)IWbemServices_Release(svc);if(loc)IWbemLocator_Release(loc);
}
static void unlock(void){
 IWbemLocator *loc=NULL;IWbemServices *svc=NULL;IWbemClassObject *cls=NULL,*sig=NULL,*input=NULL,*out=NULL;
 HRESULT h=connect_wmi(&loc,&svc);if(FAILED(h))goto end;
 const WCHAR *methodName=action==1?L"UnlockWithNumericalPassword":action==2?L"UnlockWithPassphrase":action==3?L"Decrypt":action==4?L"DisableKeyProtectors":L"EnableKeyProtectors";
 BSTR cn=SysAllocString(L"Win32_EncryptableVolume"),mn=SysAllocString(methodName),op=SysAllocString(chosenpath);
 h=IWbemServices_GetObject(svc,cn,0,NULL,&cls,NULL);SysFreeString(cn);
 if(SUCCEEDED(h))h=IWbemClassObject_GetMethod(cls,methodName,0,&sig,NULL);
 if(SUCCEEDED(h)&&sig)h=IWbemClassObject_SpawnInstance(sig,0,&input);
 if(SUCCEEDED(h)&&(action==1||action==2)&&!input)h=E_INVALIDARG;
 if(SUCCEEDED(h)&&(action==1||action==2)){
 VARIANT v;VariantInit(&v);v.vt=VT_BSTR;v.bstrVal=SysAllocString(credential);
 h=IWbemClassObject_Put(input,action==1?L"NumericalPassword":L"Passphrase",0,&v,0);
 if(v.bstrVal){SecureZeroMemory(v.bstrVal,SysStringLen(v.bstrVal)*sizeof(WCHAR));}
 VariantClear(&v);
 }
 if(SUCCEEDED(h))h=IWbemServices_ExecMethod(svc,op,mn,0,NULL,input,&out,NULL);
 SysFreeString(op);SysFreeString(mn);
 if(SUCCEEDED(h)&&out){VARIANT ret;VariantInit(&ret);h=IWbemClassObject_Get(out,L"ReturnValue",0,&ret,NULL,NULL);if(SUCCEEDED(h)&&(ret.vt==VT_I4||ret.vt==VT_UI4)){DWORD code=ret.ulVal;if(code==0&&(action==1||action==2))unlockSucceeded=TRUE;WCHAR line[400];swprintf(line,400,L"%ls on %ls: %ls (0x%08lX).\r\n%ls\r\n\r\n",methodName,target,code==0?L"SUCCESS":L"FAILED",code,code==0?(action==3?L"Decryption started; it can take a long time. Refresh to check status.":L"Request completed."):L"Check the credential, volume state, administrator rights and PE components.");append(line);}else append(L"No valid WMI result was returned.\r\n");VariantClear(&ret);}
end: if(FAILED(h)){WCHAR msg[180];swprintf(msg,180,L"BitLocker operation failed: HRESULT 0x%08lX.\r\n\r\n",(unsigned long)h);append(msg);}if(out)IWbemClassObject_Release(out);if(input)IWbemClassObject_Release(input);if(sig)IWbemClassObject_Release(sig);if(cls)IWbemClassObject_Release(cls);if(svc)IWbemServices_Release(svc);if(loc)IWbemLocator_Release(loc);
}
static DWORD WINAPI worker(void *unused){(void)unused;HRESULT h=CoInitializeEx(NULL,COINIT_MULTITHREADED);if(FAILED(h)){SecureZeroMemory(credential,sizeof(credential));count=0;wcscpy(report,L"COM initialization failed.");PostMessageW(win,DONE,0,0);return 0;}CoInitializeSecurity(NULL,-1,NULL,NULL,RPC_C_AUTHN_LEVEL_DEFAULT,RPC_C_IMP_LEVEL_IMPERSONATE,NULL,EOAC_NONE,NULL);report[0]=0;if(action){unlock();SecureZeroMemory(credential,sizeof(credential));}scan();CoUninitialize();PostMessageW(win,DONE,0,0);return 0;}
static void start(int a){unlockSucceeded=FALSE;action=a;busy=TRUE;EnableWindow(scanbtn,FALSE);EnableWindow(unlockbtn,FALSE);EnableWindow(drives,FALSE);EnableWindow(secret,FALSE);for(int i=0;i<4;i++)EnableWindow(radios[i],FALSE);SetWindowTextW(logbox,L"Working... Please wait.");HANDLE t=CreateThread(NULL,0,worker,NULL,0,NULL);if(t)CloseHandle(t);else{busy=FALSE;EnableWindow(scanbtn,TRUE);EnableWindow(unlockbtn,TRUE);EnableWindow(drives,TRUE);EnableWindow(secret,operation==0);for(int i=0;i<4;i++)EnableWindow(radios[i],TRUE);SetWindowTextW(logbox,L"Cannot start worker thread.");SecureZeroMemory(credential,sizeof(credential));}}
static HWND ctl(const WCHAR *cls,const WCHAR *text,DWORD style,int x,int y,int w,int h,int id){HWND c=CreateWindowW(cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,win,(HMENU)(INT_PTR)id,NULL,NULL);SendMessageW(c,WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),TRUE);return c;}
#define HOOKROOT L"Software\\Classes\\Drive\\shell"
#define BACKUPROOT L"Software\\IndependentBitLockerManager\\DriveHook"
#define HOOKVERB L"IndependentBitLockerOpen"
static int hook(BOOL install){
 HKEY shell=NULL,backup=NULL;LONG e;DWORD mode=0,size=sizeof(mode),disp=0;
 e=RegCreateKeyExW(HKEY_CURRENT_USER,HOOKROOT,0,NULL,0,KEY_READ|KEY_WRITE,NULL,&shell,&disp);if(e)goto fail;
 e=RegCreateKeyExW(HKEY_CURRENT_USER,BACKUPROOT,0,NULL,0,KEY_READ|KEY_WRITE,NULL,&backup,NULL);if(e)goto fail;
 RegQueryValueExW(backup,L"Installed",NULL,NULL,(BYTE*)&mode,&size);
 if(install){
 if(!mode){BYTE original[4096];DWORD len=sizeof(original),type=REG_SZ;LONG q=RegQueryValueExW(shell,NULL,NULL,&type,original,&len);DWORD present=q==ERROR_SUCCESS;
 if(q!=ERROR_SUCCESS&&q!=ERROR_FILE_NOT_FOUND){e=q;goto fail;}
 if(present&&type!=REG_SZ&&type!=REG_EXPAND_SZ){e=ERROR_INVALID_DATA;goto fail;}
 e=RegSetValueExW(backup,L"Present",0,REG_DWORD,(BYTE*)&present,sizeof(present));if(e)goto fail;
 e=RegSetValueExW(backup,L"Type",0,REG_DWORD,(BYTE*)&type,sizeof(type));if(e)goto fail;
 if(present){e=RegSetValueExW(backup,L"Original",0,REG_BINARY,original,len);if(e)goto fail;}
 mode=1;e=RegSetValueExW(backup,L"Installed",0,REG_DWORD,(BYTE*)&mode,sizeof(mode));if(e)goto fail;
 }
 WCHAR exe[MAX_PATH],command[MAX_PATH+60];DWORD n=GetModuleFileNameW(NULL,exe,MAX_PATH);if(n==0||n>=MAX_PATH){e=ERROR_BUFFER_OVERFLOW;goto fail;}
 swprintf(command,MAX_PATH+60,L"\"%ls\" --open %%1",exe);
 HKEY verb=NULL;e=RegCreateKeyExW(shell,HOOKVERB,0,NULL,0,KEY_WRITE,NULL,&verb,NULL);if(e)goto fail;
 const WCHAR label[]=L"Open / unlock BitLocker";e=RegSetValueExW(verb,NULL,0,REG_SZ,(BYTE*)label,sizeof(label));RegCloseKey(verb);if(e)goto fail;
 HKEY commandKey=NULL;e=RegCreateKeyExW(shell,HOOKVERB L"\\command",0,NULL,0,KEY_WRITE,NULL,&commandKey,NULL);if(e)goto fail;
 e=RegSetValueExW(commandKey,NULL,0,REG_SZ,(BYTE*)command,(DWORD)((wcslen(command)+1)*sizeof(WCHAR)));RegCloseKey(commandKey);if(e)goto fail;
 e=RegSetValueExW(shell,NULL,0,REG_SZ,(BYTE*)HOOKVERB,sizeof(HOOKVERB));if(e)goto fail;
 }else{
 WCHAR current[128]={0};DWORD len=sizeof(current),type=0;LONG q=RegQueryValueExW(shell,NULL,NULL,&type,(BYTE*)current,&len);
 if(!mode){MessageBoxW(NULL,L"No saved integration settings found. Nothing was changed.",L"BitLocker Manager",MB_OK);RegCloseKey(shell);RegCloseKey(backup);return 0;}
 if(q==ERROR_SUCCESS&&type==REG_SZ&&len>=sizeof(WCHAR)&&len<=sizeof(current)&&current[(len/sizeof(WCHAR))-1]==0&&wcscmp(current,HOOKVERB)==0){
 DWORD present=0;size=sizeof(present);e=RegQueryValueExW(backup,L"Present",NULL,NULL,(BYTE*)&present,&size);if(e)goto fail;
 if(present){BYTE original[4096];len=sizeof(original);size=sizeof(type);e=RegQueryValueExW(backup,L"Type",NULL,NULL,(BYTE*)&type,&size);if(e)goto fail;e=RegQueryValueExW(backup,L"Original",NULL,NULL,original,&len);if(e)goto fail;e=RegSetValueExW(shell,NULL,0,type,original,len);if(e)goto fail;}
 else{e=RegDeleteValueW(shell,NULL);if(e&&e!=ERROR_FILE_NOT_FOUND)goto fail;}
 }
 RegDeleteTreeW(shell,HOOKVERB);RegCloseKey(backup);backup=NULL;RegDeleteTreeW(HKEY_CURRENT_USER,BACKUPROOT);
 }
 if(backup){RegCloseKey(backup);}
 RegCloseKey(shell);SHChangeNotify(SHCNE_ASSOCCHANGED,SHCNF_IDLIST,NULL,NULL);
 MessageBoxW(NULL,install?L"Drive double-click integration installed for this user. Keep this EXE in its current location. Restart Explorer if needed. Other file managers may ignore this setting.":L"Drive integration removed; the previous default action was restored where applicable.",L"BitLocker Manager",MB_OK|MB_ICONINFORMATION);return 0;
fail: if(shell)RegCloseKey(shell);if(backup)RegCloseKey(backup);WCHAR msg[160];swprintf(msg,160,L"Integration failed (Windows error %ld). Run --remove-doubleclick to restore any saved default.",e);MessageBoxW(NULL,msg,L"BitLocker Manager",MB_OK|MB_ICONERROR);return 1;
}
static void browse(WCHAR letter){WCHAR exe[MAX_PATH],arg[4]={letter,L':',L'\\',0};GetWindowsDirectoryW(exe,MAX_PATH);wcscat(exe,L"\\explorer.exe");if((INT_PTR)ShellExecuteW(NULL,L"open",exe,arg,NULL,SW_SHOWNORMAL)<=32)MessageBoxW(win,L"Cannot start Windows Explorer. This PE may use a different file manager.",L"BitLocker Manager",MB_OK);}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){case WM_CREATE:win=h;
 ctl(L"BUTTON",L"BitLocker drives",BS_GROUPBOX,14,12,604,222,0);
 ctl(L"STATIC",L"Drive:",0,30,43,60,23,0);
 drives=ctl(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,98,39,365,220,10);
 scanbtn=ctl(L"BUTTON",L"Refresh",WS_TABSTOP,478,38,122,28,11);
 const WCHAR *labels[4]={L"Unlock",L"Turn off",L"Suspend",L"Resume"};
 for(int i=0;i<4;i++)radios[i]=ctl(L"BUTTON",labels[i],BS_AUTORADIOBUTTON|WS_TABSTOP|(i==0?WS_GROUP:0),30+i*145,88,135,28,20+i);
 SendMessageW(radios[0],BM_SETCHECK,BST_CHECKED,0);
 ctl(L"STATIC",L"Enter BitLocker password or 48-digit recovery key:",0,30,131,550,22,0);
 secret=ctl(L"EDIT",L"",WS_BORDER|ES_PASSWORD|ES_AUTOHSCROLL|WS_TABSTOP,30,164,455,29,12);SendMessageW(secret,EM_SETLIMITTEXT,1000,0);
 showbtn=ctl(L"BUTTON",L"Show",WS_TABSTOP,496,164,104,29,15);
 ctl(L"STATIC",L"Lists WMI volumes, including protection-off and decrypted volumes.",0,20,247,590,23,0);
 unlockbtn=ctl(L"BUTTON",L"Run",WS_TABSTOP,478,279,122,32,13);
 ctl(L"STATIC",L"Status / operation result:",0,20,286,420,22,0);
 logbox=ctl(L"EDIT",L"",WS_BORDER|ES_MULTILINE|ES_READONLY|WS_VSCROLL|ES_AUTOVSCROLL,20,325,590,184,14);
 SetTimer(h,1,100,NULL);return 0;
case WM_TIMER:KillTimer(h,1);start(0);return 0;
case WM_COMMAND:
 if(LOWORD(w)==15){BOOL masked=SendMessageW(secret,EM_GETPASSWORDCHAR,0,0)!=0;SendMessageW(secret,EM_SETPASSWORDCHAR,masked?0:L'*',0);SetWindowTextW(showbtn,masked?L"Hide":L"Show");InvalidateRect(secret,NULL,TRUE);return 0;}
 if(LOWORD(w)>=20&&LOWORD(w)<=23&&!busy){operation=LOWORD(w)-20;EnableWindow(secret,operation==0);if(operation!=0)SetWindowTextW(secret,L"");return 0;}
 if(LOWORD(w)==11&&!busy)start(0);
 if(LOWORD(w)==13&&!busy){
 int idx=(int)SendMessageW(drives,CB_GETCURSEL,0,0);if(idx<0||idx>=count){MessageBoxW(h,L"Select a BitLocker volume first.",L"BitLocker",MB_OK);return 0;}
 int requested=operation==0?2:operation==1?3:operation==2?4:5;
 if(operation==0&&locks[idx]!=1){MessageBoxW(h,L"Select a LOCKED volume. For UNKNOWN state, check WMI support first.",L"BitLocker",MB_OK);return 0;}
 if(operation!=0&&locks[idx]!=0&&!(operation==3&&locks[idx]<0)){MessageBoxW(h,L"Unlock the volume before changing protection. If the status is unavailable, refresh or use Resume to restore protection.",L"BitLocker",MB_OK);return 0;}
 if(operation!=0&&conversions[idx]==0){MessageBoxW(h,L"This volume is fully decrypted. There is no BitLocker encryption protection to change.",L"BitLocker",MB_OK);return 0;}
 if(operation==1&&MessageBoxW(h,L"Turn off BitLocker on the selected volume? This decrypts its data and removes encryption protection. Decryption can take hours. Keep power connected.",L"Confirm decryption",MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2)!=IDYES)return 0;
 if(operation==2&&MessageBoxW(h,L"Suspend protection on the selected volume until you explicitly Resume? A clear key may be stored on the volume, reducing protection. Resume protection promptly. This operation may be unsupported for some data volumes.",L"Confirm suspension",MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2)!=IDYES)return 0;
 if(operation==0){GetWindowTextW(secret,credential,1024);if(!credential[0]){MessageBoxW(h,L"Enter a password or recovery key.",L"BitLocker",MB_OK);return 0;}
 WCHAR digits[49];int n=0;BOOL numeric=TRUE;for(int i=0;credential[i];i++){if(credential[i]>=L'0'&&credential[i]<=L'9'){if(n<48)digits[n]=credential[i];n++;}else if(credential[i]!=L'-'&&credential[i]!=L' ')numeric=FALSE;}
 if(numeric&&n==48){digits[48]=0;BOOL valid=TRUE;for(int i=0;i<8;i++){WCHAR g[7];wmemcpy(g,digits+i*6,6);g[6]=0;unsigned long v=wcstoul(g,NULL,10);if(v>720885||v%11)valid=FALSE;}
 if(!valid){SecureZeroMemory(credential,sizeof(credential));SecureZeroMemory(digits,sizeof(digits));MessageBoxW(h,L"Invalid recovery key checksum. Check all eight groups.",L"BitLocker",MB_OK);return 0;}
 for(int i=0;i<8;i++){wmemcpy(credential+i*7,digits+i*6,6);credential[i*7+6]=i==7?0:L'-';}requested=1;}
 SecureZeroMemory(digits,sizeof(digits));SetWindowTextW(secret,L"");SendMessageW(secret,EM_SETPASSWORDCHAR,L'*',0);SetWindowTextW(showbtn,L"Show");}
 target[0]=letters[idx];target[1]=L':';target[2]=0;wcscpy(chosenpath,paths[idx]);start(requested);
 }return 0;
case DONE:{if(launchedFromDrive&&unlockSucceeded){for(int i=0;i<count;i++)if(letters[i]==target[0]&&locks[i]==0){busy=FALSE;browse(target[0]);DestroyWindow(h);return 0;}}SendMessageW(drives,CB_RESETCONTENT,0,0);int selected=-1;for(int i=0;i<count;i++){WCHAR s[100];swprintf(s,100,L"%lc:  %ls",letters[i],locks[i]==1?L"LOCKED":conversions[i]==0?L"FULLY DECRYPTED":locks[i]<0?L"STATUS UNAVAILABLE":protections[i]==0?L"UNLOCKED - PROTECTION OFF":L"UNLOCKED");SendMessageW(drives,CB_ADDSTRING,0,(LPARAM)s);if(selected<0&&locks[i]==1)selected=i;}if(openRequest){openRequest=FALSE;int matched=-1;for(int i=0;i<count;i++)if(letters[i]==openLetter)matched=i;
 if(matched>=0&&locks[matched]==1){selected=matched;}else if(matched>=0&&locks[matched]==0){busy=FALSE;browse(openLetter);DestroyWindow(h);return 0;}
 else if(matched<0&&wcsstr(report,L"unavailable")==NULL&&wcsstr(report,L"Cannot")==NULL&&wcsstr(report,L"incomplete")==NULL){busy=FALSE;browse(openLetter);DestroyWindow(h);return 0;}
 }
 if(action){for(int i=0;i<count;i++)if(letters[i]==target[0])selected=i;}
 if(selected<0&&count){selected=0;}
 if(selected>=0){SendMessageW(drives,CB_SETCURSEL,selected,0);}
 SetWindowTextW(logbox,report);busy=FALSE;EnableWindow(scanbtn,TRUE);EnableWindow(unlockbtn,TRUE);EnableWindow(drives,TRUE);EnableWindow(secret,operation==0);for(int i=0;i<4;i++)EnableWindow(radios[i],TRUE);return 0;}
case WM_CLOSE:if(busy){MessageBoxW(h,L"An operation is running. Please wait before closing.",L"BitLocker",MB_OK);return 0;}DestroyWindow(h);return 0;
case WM_DESTROY:SecureZeroMemory(credential,sizeof(credential));PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE prev,PWSTR cmd,int show){(void)prev;
 int argc=0;LPWSTR *argv=CommandLineToArgvW(GetCommandLineW(),&argc);(void)cmd;
 if(argv&&argc>1){if(wcscmp(argv[1],L"--install-doubleclick")==0){LocalFree(argv);return hook(TRUE);}if(wcscmp(argv[1],L"--remove-doubleclick")==0){LocalFree(argv);return hook(FALSE);}if(argc>2&&wcscmp(argv[1],L"--open")==0){WCHAR c=argv[2][0];if(c>=L'a'&&c<=L'z')c-=32;if(c>=L'A'&&c<=L'Z'){openLetter=c;openRequest=TRUE;launchedFromDrive=TRUE;}}}if(argv)LocalFree(argv);
 WNDCLASSW wc={0};wc.lpfnWndProc=proc;wc.hInstance=inst;wc.lpszClassName=L"IndependentBitLockerHelper";wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);RegisterClassW(&wc);HWND h=CreateWindowW(wc.lpszClassName,L"BitLocker Manager - Independent (Test 2)",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,650,560,NULL,NULL,inst,NULL);ShowWindow(h,show);MSG msg;while(GetMessageW(&msg,NULL,0,0)>0){if(!IsDialogMessageW(h,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}return 0;}
