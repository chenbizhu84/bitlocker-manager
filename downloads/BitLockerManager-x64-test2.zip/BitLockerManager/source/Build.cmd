@echo off
setlocal
cd /d "%~dp0"
windres app.rc -O coff -o app-res.o
if errorlevel 1 exit /b 1
 gcc BitLockerHelper.c app-res.o -o ..\bdemgr.exe -municode -mwindows -O2 -Wall -Wextra -Werror -static -Wl,--major-os-version,6,--minor-os-version,1,--major-subsystem-version,6,--minor-subsystem-version,1 -lole32 -loleaut32 -lwbemuuid -luuid -lgdi32 -luser32 -lshell32 -ladvapi32
