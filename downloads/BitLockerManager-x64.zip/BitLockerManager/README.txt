﻿BitLocker Manager - Independent 1.0 (x64)

独立重写的英文界面工具，不包含原版 Anhdv 程序，不修改或绕过其环境检查。
布局参考用户提供的截图，并非原程序的逐像素复制。

替换 Anhdv 原有入口（优先使用这个方法）：
1. 解压整个 ZIP，保留里面的新 bdemgr.exe。
2. 找到 PE 中原来的 bdemgr.exe，关闭正在运行的工具。
3. 将原版 bdemgr.exe 拖到 Replace-Anhdv.cmd 上。
   脚本会先在原目录保存 bdemgr.anhdv-original.exe，再替换。
4. 测试原来的 Anhdv BitLocker 入口。
5. 要还原，将替换后的目标 bdemgr.exe 拖到 Restore-Anhdv.cmd 上。
如果入口只是直接运行此路径，这样即可改用新工具。原有 .anhdv 无需修改。
如果启动器每次从归档重新解压原版，或验证原程序，则需要进一步定位其来源，
此包不修改加密 .anhdv 或 Anhdv 归档。当前未取得完整 PE，不能验证原入口。
X: RAM 盘中的修改会在 PE 重启后丢失；需要持久保存时应修改 PE 的源文件。

磁盘双击集成（可选，与替换原有入口不同）：
对于启动后生成的 Windows\Temp\bdemgr.exe，推荐这个方法，避免覆盖临时程序。
以管理员运行 Install-Drive-DoubleClick.cmd，脚本会把新程序复制到：
%SystemRoot%\System32\IndependentBitLockerManager\BitLockerManager.exe
然后安装磁盘双击关联。原来的 Temp\bdemgr.exe 和 .anhdv 不变。
它设置当前用户 HKCU\Software\Classes\Drive\shell 的默认操作，影响所有盘符。
双击时，WMI 检测到卷已锁定则打开工具并选中它；未加密或已解锁则启动 Explorer。
成功解锁后自动浏览该盘。WMI 无法使用时显示工具内的诊断信息。
通过 Remove-Drive-DoubleClick.cmd 移除并恢复已备份的默认操作。
安装后不要移动或删除 System32 下的独立 EXE；原解压包可以移动。
原版 Anhdv 菜单项仍可能调用旧临时程序，本方法改变的是 Explorer 磁盘默认打开动作。
若要更改 Anhdv 原菜单项，需要取得生成它的启动配置。
在 Anhdv 初始化完成后运行安装脚本；若其脚本稍后重设关联，需在它之后再安装。
Explorer 可能需要重启。其他文件管理器或原有 shell 扩展可能不采用此设置。
注册表备份位置：HKCU\Software\IndependentBitLockerManager\DriveHook。
PE 的注册表通常不持久保存；若需每次启动生效，应在 PE 启动脚本中重新安装。
运行要求管理员权限，普通 Windows 可能显示 UAC 提示。

功能：
- 自动扫描有盘符的 BitLocker 卷，标注 LOCKED / UNLOCKED / UNKNOWN，优先选择锁定卷。
- 忽略确认完全解密的卷；不能确认状态的卷可能作为 UNKNOWN 显示。
- 输入密码或 48 位恢复密钥；支持密钥中的横线或空格。
- Show / Hide；解锁时清空输入框，不写密钥日志，不将密钥传到命令行。
- Turn off：解密整个卷，执行前确认，解密可能持续数小时。
- Suspend：暂停密钥保护，执行前确认；需要之后显式 Resume。
- Resume：恢复密钥保护。
- 状态区显示加密百分比、保护状态和操作错误码。
  conversion state: 0=完全解密, 1=完全加密, 2=正在加密,
  3=正在解密, 4=加密已暂停, 5=解密已暂停。
“UNLOCKED”不等于未加密；卷已解锁仍可处于加密状态。
BitLocker 按卷工作，不按整块物理 DISK 工作；无盘符的卷需先分配盘符。

兼容性与依赖：
当前只提供 64 位版本，目标为 Windows 7 SP1 / 8 / 8.1 / 10 / 11 x64 及相应 WinPE。
32 位 Windows / 32 位 PE 不能运行此 EXE，ARM64 也未验证。
使用原生 Win32 + BitLocker WMI，不需要 .NET、PowerShell 或 manage-bde.exe。
PE 必须包含 WinPE-WMI、WinPE-SecureStartup 及对应的 BitLocker WMI provider。
只复制此 EXE 到精简 PE 并不能补齐缺失的系统组件。
目标卷的解锁方式、加密格式及加密算法必须受当前 Windows / PE 支持；
老版本 PE 可能无法处理新系统创建的 XTS-AES 等加密卷。
不支持破解或跳过有效密码/恢复密钥。原版 Anhdv 解锁工具也需要有效凭据。

验证范围：
已完成 x64 交叉编译（-Wall -Wextra -Werror）及 PE 导入表/清单静态检查。
EXE 仅直接依赖 Windows 系统 DLL，没有附带第三方运行时。
当前环境不是 Windows；未验证 GUI、真实 BitLocker 卷操作、Explorer 关联、
Anhdv 启动入口，以及各 Windows / PE 版本的实际行为。
这是待实机测试版本，不能据此宣称全平台兼容已通过。

源码在 source 目录。用 x64 MinGW-w64 gcc + windres 运行 Build.cmd 可重建。
